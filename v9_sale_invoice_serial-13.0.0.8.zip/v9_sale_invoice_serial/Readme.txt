
=> 13.0.0.3 : Improved related, demanded apps link version.


Date 2nd april 2020
version 13.0.0.4
issue solve:-
	we need to display the scanned serial number on sale and invoice report also.

=> 13.0.0.5 : Improved an index as per latest changes.
==>13.0.0.6:fixed issue of lot in delivery.
==>13.0.0.7:fixed issue of validation error.
==>13.0.0.8: (12-11-2020) => import usererror in stock move file
